#!/usr/bin/env python

# Copyright (C) 2017 Electric Movement Inc.
#
# This file is part of Robotic Arm: Pick and Place project for Udacity
# Robotics nano-degree program
#
# All Rights Reserved.

# Author: Harsh Pandya

# import modules
import rospy
import tf
import numpy as np
from numpy import array
from kuka_arm.srv import *
from trajectory_msgs.msg import JointTrajectory, JointTrajectoryPoint
from geometry_msgs.msg import Pose
from mpmath import *
from sympy import *
import math


def handle_calculate_IK(req):
    rospy.loginfo("Received %s eef-poses from the plan" % len(req.poses))
    if len(req.poses) < 1:
        print "No valid poses received"
        return -1
    else:
        print req.poses
	# Initialize service response
        joint_trajectory_list = []
        for x in xrange(0, len(req.poses)):
                # IK code starts here
                joint_trajectory_point = JointTrajectoryPoint()

                # Define DH param symbols
                q1, q2, q3, q4, q5, q6, q7 = symbols('q1:8') # this is theta
                d1,d2,d3,d4,d5,d6,d7 = symbols('d1:8')
                a0,a1,a2,a3,a4,a5,a6 = symbols('a0:7')
                al0, al1, al2, al3, al4, al5, al6 = symbols('al0:7')


                # Joint angle symbols
                wx, wy, wz = symbols('wx, wy, wz')
                pxef, pyef, pzef = symbols('pxef, pyef, pzef')
                px, py, pz = symbols('px, py, pz')
                Yaw, Pitch, Roll = symbols('Yaw, Pitch, Roll')
                pxtheta, pytheta, theta1, thata2 = symbols('pxtheta, pytheta, theta1, thata2')


                # Modified DH params
                s = {al0: 0,        a0: 0,          d1: 0.75,     
                al1: -pi/2,    a1: 0.35,       d2: 0,      q2: q2-pi/2, 
                al2: 0,        a2: 1.25,       d3: 0,           
                al3: -pi/2,    a3: -0.054,     d4: 1.50,        
                al4: pi/2,     a4: 0,          d5: 0,          
                al5: -pi/2,    a5: 0,          d6: 0,          
                al6: 0,        a6: 0,          d7: 0.303,   q7: 0}


                # Define Modified DH Transformation matrix
                # Base_link to link 1 Transform Matrix
                T0_1 = Matrix([[             cos(q1),            -sin(q1),            0,              a0],
                [ sin(q1)*cos(al0), cos(q1)*cos(al0), -sin(al0), -sin(al0)*d1],
                [ sin(q1)*sin(al0), cos(q1)*sin(al0),  cos(al0),  cos(al0)*d1],
                [                   0,                   0,            0,               1]])
                T0_1 = T0_1.subs(s)
                # Link 1 to link 2 Transform Matrix
                T1_2 = Matrix([[             cos(q2),            -sin(q2),            0,              a1],
                           [ sin(q2)*cos(al1), cos(q2)*cos(al1), -sin(al1), -sin(al1)*d2],
                           [ sin(q2)*sin(al1), cos(q2)*sin(al1),  cos(al1),  cos(al1)*d2],
                           [                   0,                   0,            0,               1]])
                T1_2 = T1_2.subs(s)
                # Link 2 to link 3 Transform Matrix
                T2_3 = Matrix([[             cos(q3),            -sin(q3),            0,              a2],
                           [ sin(q3)*cos(al2), cos(q3)*cos(al2), -sin(al2), -sin(al2)*d3],
                           [ sin(q3)*sin(al2), cos(q3)*sin(al2),  cos(al2),  cos(al2)*d3],
                           [                   0,                   0,            0,               1]])
                T2_3 = T2_3.subs(s)
                # Link 3 to link 4 Transform Matrix
                T3_4 = Matrix([[             cos(q4),            -sin(q4),            0,              a3],
                           [ sin(q4)*cos(al3), cos(q4)*cos(al3), -sin(al3), -sin(al3)*d4],
                           [ sin(q4)*sin(al3), cos(q4)*sin(al3),  cos(al3),  cos(al3)*d4],
                           [                   0,                   0,            0,               1]])
                T3_4 = T3_4.subs(s)
                # Link 4 to link 5 Transform Matrix
                T4_5 = Matrix([[             cos(q5),            -sin(q5),            0,              a4],
                           [ sin(q5)*cos(al4), cos(q5)*cos(al4), -sin(al4), -sin(al4)*d5],
                           [ sin(q5)*sin(al4), cos(q5)*sin(al4),  cos(al4),  cos(al4)*d5],
                           [                   0,                   0,            0,               1]])
                T4_5 = T4_5.subs(s)
                # Link 5 to link 6 Transform Matrix
                T5_6 = Matrix([[             cos(q6),            -sin(q6),            0,              a5],
                           [ sin(q6)*cos(al5), cos(q6)*cos(al5), -sin(al5), -sin(al5)*d6],
                           [ sin(q6)*sin(al5), cos(q6)*sin(al5),  cos(al5),  cos(al5)*d6],
                           [                   0,                   0,            0,               1]])
                T5_6 = T5_6.subs(s)
                # Link 6 to link gripper Transform Matrix
                T6_G = Matrix([[             cos(q7),            -sin(q7),            0,              a6],
                           [ sin(q7)*cos(al6), cos(q7)*cos(al6), -sin(al6), -sin(al6)*d7],
                           [ sin(q7)*sin(al6), cos(q7)*sin(al6),  cos(al6),  cos(al6)*d7],
                           [                   0,                   0,            0,               1]])
                T6_G = T6_G.subs(s)
                R_z = Matrix([[     cos(pi),            -sin(pi),             0,              0],
                [    sin(pi),             cos(pi),             0,              0],
                [            0,                      0,              1,              0],
                [            0,                      0,              0,              1]])


                R_y = Matrix([[     cos(-pi/2),                  0,  sin(-pi/2),              0],
                           [            0,                      1,              0,              0],
                           [    -sin(-pi/2),                 0,  cos(-pi/2),              0],
                           [            0,                      0,              0,              1]])
                R_corr = simplify(R_z * R_y)


                # Create individual transformation matrices
                T0_2 = T0_1 * T1_2 # base to 2
                T0_3 = T0_2 * T2_3 # base to 3
                T0_4 = T0_3 * T3_4 # base to 4
                T0_5 = T0_4 * T4_5 # base to 5
                T0_6 = T0_5 * T5_6 # base to 6
                T0_G = T0_6 * T6_G # base to gripper

                # Extract end-effector position and orientation from request
                pxef = req.poses[x].position.x
                pyef = req.poses[x].position.y
                pzef = req.poses[x].position.z
                ox =req.poses[x].orientation.x
                oy=req.poses[x].orientation.y
                oz =req.poses[x].orientation.z
                ow =req.poses[x].orientation.w
                print(" ")
                print("orientation x, y, z", pxef, pyef, pzef)
                print("angle x, y, z,w", ox, oy, oz, ow)
                print("")
                # roll, pitch, yaw = end-effector orientation
                (Roll, Pitch, Yaw) = tf.transformations.euler_from_quaternion(
                [req.poses[x].orientation.x, req.poses[x].orientation.y,
                    req.poses[x].orientation.z, req.poses[x].orientation.w])
                print("ROLL, Pitch, Yaw:", Roll, Pitch, Yaw)

                # Rotation Matrix for wrist centre solution
                R_x = Matrix([[ 1,              0,        0],
                          [ 0,        cos(Roll), -sin(Roll)],
                          [ 0,        sin(Roll),  cos(Roll)]])

                R_y = Matrix([[ cos(Pitch),        0,  sin(Pitch)],
                          [       0,        1,        0],
                          [-sin(Pitch),        0,  cos(Pitch)]])

                R_z = Matrix([[ cos(Yaw), -sin(Yaw),        0],
                          [ sin(Yaw),  cos(Yaw),        0],
                          [ 0,              0,        1]])
                R_Roll = R_z*R_y*R_x


                # Calculte Wrist Centre
                pmatrix = Matrix([[pxef],[pyef],[pzef]])
                commong = 0.303*R_Roll*Matrix([[1],[0],[0]])
                wristxyz = pmatrix-commong
                print("wristcentre ",wristxyz)


                # Calculate joint angles using Geometric IK method
                px = wristxyz[0]
                py = wristxyz[1]
                pz = wristxyz[2]


                # THETA 1 Calculation******
                theta1 = atan2(py, px)
                a1 = 0.35
                a2 = 1.25
                d1 = 0.75
                d4 = 1.5
                


                # calculate the small drop of joint 2
                armangle = atan2(pz-(1.94645), px)
                px = px-0.054*(sin(armangle))
                pz = pz+0.054*(cos(armangle))

                # determine the length from origin to wrist centre looking top down
                #to determine the X value for theta 2, as arm moves, the length has to be determined
                #by looking at x/y values
                pxtheta = sqrt(py*py+px*px)
                print("pxtheta",pxtheta)


                # reference calculations to centre of Joint 1
                pxtheta = pxtheta-a1
                pztheta = pz - d1

                # cosine law to find joint angle 2
                D=(pxtheta*pxtheta + pztheta*pztheta - a2*a2-d4*d4)/(2*a2*d4)
                theta3 = atan2(-sqrt(1-D*D),D)
                S1=((a2+d4*cos(theta3))*pztheta-d4*sin(theta3)*pxtheta)/(pxtheta*pxtheta + pztheta*pztheta)
                C1=((a2+d4*cos(theta3))*pxtheta+d4*sin(theta3)*pztheta)/(pxtheta*pxtheta + pztheta*pztheta)
                theta2 = atan2(S1,C1)


                # THETA 2 calculation********
                theta2 = -(theta2-math.pi/2)
                # THETA 2 calculation********
                theta3 = -(theta3+math.pi/2)

                # Due to unexpected arm rotation around joint 4 at the bucket, if statement is implemented in order to avoid
                # hitting the bucket.
                if px<0.20:
                        theta3 = theta3-0.08
                        theta1 = theta1-0.10


                print("theta1", theta1)
                print("theta2", theta2)
                print("theta3",theta3)


                # process to calculate remainder of angles
                R0_3=T0_3.extract([0,1,2],[0,1,2])
                R0_3 = R0_3.evalf(subs={q1: theta1, q2: theta2, q3: theta3})

                R3_6 = simplify(Transpose(R0_3))
##                R3_6 = R3_6 * R_Roll
                

                R3_6 = np.array(R3_6).astype(np.float64) 
                # convert from Rotation Matrix 3_6 to corresponding Euler angles
                alpha, beta, gamma = tf.transformations.euler_from_matrix(R3_6, axes = 'ryzy')
                alpha = alpha -pi/2
                beta = beta -pi/2
                gamma = gamma 
                print(" ")
                print(" ")
                print(" ")
                print("alpha in degrees is = ",(math.degrees(alpha)))
                print("alpha is = ",math.radians(math.degrees(alpha)))
                print("beta in degrees is = ",(math.degrees(beta)))
                print("beta is = ",math.radians(math.degrees(beta)))
                print("gamma in degrees is = ",(math.degrees(gamma)))
                print("gamma is = ",math.radians(math.degrees(gamma)))

                # In order to avoid Joint link 4 and 3 collisions, a constraint below is put in place.
                if gamma>2.15:
                        gamma = 2.15*2-gamma
                elif gamma<-2.15:
                        gamma=-2.15*2-gamma
                else:
                    gamma = gamma 
                theta4 = alpha
                theta5 = gamma
                theta6 = beta
                        


                    # Populate response for the IK request
                    # In the next line replace theta1,theta2...,theta6 by your joint angle variables
                joint_trajectory_point.positions = [theta1, theta2, theta3, theta4, theta5, theta6]
                joint_trajectory_list.append(joint_trajectory_point)

        rospy.loginfo("length of Joint Trajectory List: %s" % len(joint_trajectory_list))
        return CalculateIKResponse(joint_trajectory_list)


def IK_server():
    # initialize node and declare calculate_ik service
    rospy.init_node('IK_server')
    s = rospy.Service('calculate_ik', CalculateIK, handle_calculate_IK)
    print "Ready to receive an IK request"
    rospy.spin()

if __name__ == "__main__":
    IK_server()
